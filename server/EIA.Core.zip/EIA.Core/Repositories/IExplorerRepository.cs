using EIA.Domain.Entities;

namespace EIA.Core.Repositories;

public interface IExplorerRepository
{
    Task AddAsync(Explorer explorer);

    Task<List<Explorer>> GetAllAsync();

    Task<Explorer?> GetByIdAsync(Guid id);
}
public Task<Explorer?> GetByIdAsync(Guid id)
{
    var explorer = _explorers.FirstOrDefault(x => x.Id == id);

    return Task.FromResult(explorer);
}