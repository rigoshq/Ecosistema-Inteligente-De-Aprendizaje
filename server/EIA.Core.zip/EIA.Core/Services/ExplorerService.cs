using EIA.Core.DTOs;
using EIA.Core.Repositories;
using EIA.Domain.Entities;

namespace EIA.Core.Services;

public class ExplorerService
{
    private readonly IExplorerRepository _repository;

    public ExplorerService(IExplorerRepository repository)
    {
        _repository = repository;
    }

    public async Task RegisterAsync(ExplorerRegistrationDto dto)
    {
        var explorer = new Explorer
        {
            FirstName = dto.FirstName,
            LastName = dto.LastName,
            UserName = dto.UserName,
            Email = dto.Email
        };

        await _repository.AddAsync(explorer);
    }

    public async Task<List<Explorer>> GetAllAsync()
    {
        return await _repository.GetAllAsync();
    }
    public async Task<ExplorerProfileDto?> GetProfileAsync(Guid id)
{
    var explorer = await _repository.GetByIdAsync(id);

    if (explorer == null)
        return null;

    return new ExplorerProfileDto
    {
        Id = explorer.Id,
        FirstName = explorer.FirstName,
        LastName = explorer.LastName,
        UserName = explorer.UserName,
        Level = explorer.Level,
        Experience = explorer.Experience,
        Coins = explorer.Coins,
        MissionsCompleted = explorer.MissionsCompleted,
        LaboratoriesCompleted = explorer.LaboratoriesCompleted,
        InventoryItems = explorer.Inventory.Count,
        Achievements = explorer.Achievements.Count
    };
}
}